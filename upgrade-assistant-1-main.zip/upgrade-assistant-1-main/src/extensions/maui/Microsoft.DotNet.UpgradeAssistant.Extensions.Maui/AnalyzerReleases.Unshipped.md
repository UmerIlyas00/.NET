﻿; Unshipped analyzer release
; https://github.com/dotnet/roslyn-analyzers/blob/master/src/Microsoft.CodeAnalysis.Analyzers/ReleaseTrackingAnalyzers.Help.md

### New Rules
Rule ID | Category | Severity | Notes
--------|----------|----------|-------
UA0014 | Upgrade | Warning | UsingXamarinFormsAnalyzerAnalyzer
UA0015 | Upgrade | Warning | UsingXamarinEssentialsAnalyzer 
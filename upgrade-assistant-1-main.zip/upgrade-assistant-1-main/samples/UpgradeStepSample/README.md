# Upgrade Assistant UpgradeStep sample

This sample demonstrates how to create a custom upgrade step and register it using an `IExtensionServiceProvider`.

This sample adds an extra upgrade step to Upgrade Assistant, as shown here.

![Screenshot of custom upgrade step](./images/CustomUpgradeStep.jpg)